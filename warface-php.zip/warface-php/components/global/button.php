<button 
	id=<?php echo $id; ?>
	class="
		min-w-[196px] sm:min-w-[256px] w-full inline-flex items-center justify-center p-3 text-[17px] font-medium font-tactic text-white text-md bg-azure-400 whitespace-nowrap 
		rounded-2xl transition-shadow disabled:pointer-events-none disabled:opacity-50 hover:shadow-[inset_0px_4px_23.2px_0px_#FFFFFF80]
	"
>
	<?php echo $title; ?>
</button>