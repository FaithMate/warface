<?php
	$faq = array(
		(object) [
			'summary' => 'Как пополнить?',
			'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione dolores enim temporibus fuga autem tempore!',
		],
		(object) [
			'summary' => 'Сколько длится курс?',
			'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione dolores enim temporibus fuga autem tempore!',
		],
		(object) [
			'summary' => 'Что делать если не прошла оплата',
			'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione dolores enim temporibus fuga autem tempore!',
		],
		(object) [
			'summary' => 'Бла бла',
			'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione dolores enim temporibus fuga autem tempore!',
		],
		(object) [
			'summary' => 'Бла бла',
			'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione dolores enim temporibus fuga autem tempore!',
		],
		(object) [
			'summary' => 'Бла бла',
			'content' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ratione dolores enim temporibus fuga autem tempore!',
		],
	);
?>